package com.mavin.SapConnectService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SapConnectServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
