package com.mavin.SapConnectService.manager;

import org.springframework.beans.factory.annotation.Autowired;

import com.mavin.SapConnectService.utils.MessageHelper;

public class BaseManager {
	@Autowired
	public MessageHelper messageHelper;
}
